class Execution {
    public static void main(String[] args) {
        Game game = new Game(4);
        game.play();
    }
}
